# HIOps 智能终端看护探针 (Endpoint Sensor) 奇安信桌管分发指南

## 一、 快速分发方案（推荐方案 A）

### 单文件静默自解压安装包（Zero Configuration）
- **文件**: `HIOps-EndpointSensor-Setup.exe`
- **特点**: 单个独立 EXE，内部内嵌了探针二进制文件与官方服务端连接配置（`192.168.114.30:5080` + 官方终端密钥），无需额外依赖。
- **奇安信桌管「软件分发」执行命令**:
  ```cmd
  HIOps-EndpointSensor-Setup.exe /S
  ```
  *(也支持 `/silent`、`/quiet`、`/qn` 等静默安装开关)*
- **安装后行为**:
  1. 自动部署至 `C:\Program Files\HIOps\Sensor\`
  2. 自动生成 `config.ini` 配置文件
  3. 自动建立 Windows 高权限登录自启任务计划（`schtasks`）
  4. 自动静默拉起后台常驻进程，立即向 `192.168.114.30:5080` 报送首次心跳

---

## 二、 脚本解压分发方案（备选方案 B）

### ZIP 压缩包解压安装
- **文件**: `HIOps-EndpointSensor-Client-v0.3.zip`
- **包内清单**:
  - `HIOps-EndpointSensor-Setup.exe` (单文件自解压静默安装器)
  - `HIOps.EndpointSensor.exe` (探针主程序，AnyCPU，兼容 Win7 SP1 x86 至 Win11 x64)
  - `config.ini` (平台基地址与鉴权 Key 配置文件)
  - `install.bat` (静默安装脚本)
  - `uninstall.bat` (静默卸载清理脚本)
- **奇安信桌管下发配置**:
  - 分发任务类型: **压缩包解压并执行**
  - 解压后执行脚本: `install.bat`
  - 静默卸载脚本: `uninstall.bat`

---

## 三、 自定义配置说明 (`config.ini`)

若需切换上报服务器或更改上报周期，直接修改探针目录下的 `config.ini` 即可，无需重新编译 EXE：
```ini
# HIOps 平台 API 基地址 (生产为 :5080，Docker 测试为 :5081)
ServerUrl=http://192.168.114.30:5080

# 终端鉴权凭证 (与服务端 DlpAgentKeys 表双向哈希校验)
AgentKey=hiops_3a2f5033c247fb06d2c8867fee93205fe46bd416d44c1d42d9f3fc2aa2aadaae

# 遥测心跳周期 (默认 30 秒)
HeartbeatSeconds=30
```

---

## 四、 服务端在线验证

安装完成后，打开 HIOps 统一运维控制台：
- **访问地址**: `http://192.168.114.30:5080` 或 `http://192.168.114.30:5081`
- **账号密码**: `admin` / `Admin@123`
- **查看路径**: 进入「探针看护 / 终端画像 (Agent Health)」页面，即可在列表中实时查看到刚刚下发成功的终端主机名、IP、CPU/内存/磁盘健康得分与在线心跳！
